The Speed of Clean

These are instructions for loading the projects we'll be working with.

1. Expand the overall zip file. (If you're reading this, you probably already have.) 
But - DO NOT EXPAND THE 4 ZIP FILES INSIDE.

2. Go into Eclipse. 

3. If you want to work in a new workspace, create one:
   File > Switch Workspace > Other - then create a new directory.

4. There are four zip files, one for each project we'll be working on.
For each zip file:

    File > Import... > Existing Project Into Workspace
    Next
    Select the radio button for "Archive File" - and select the zip.
    Then Finish.

You should be able to right-click on tests and run them, have things work right from there. 

5. After you're done, you can do Switch Workspace again to your original workspace.


If you have any trouble, contact Bill Wake (William.Wake@acm.org), 
or Tom Kubit (tomkubit@yahoo.com).

